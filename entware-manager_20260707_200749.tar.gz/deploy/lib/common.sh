#!/bin/sh
# ==============================================
# Entware Manager - общие функции для CGI
# Версия: 2.5 (чистая версия без DEBUG)
# Дата: 2026-04-01
# ==============================================

export PATH=/opt/sbin:/opt/bin:/sbin:/bin:/usr/sbin:/usr/bin
export HOME=/tmp

# --- Декодирование URL ---
url_decode() {
    printf '%s' "$1" | sed \
        -e 's/%21/_EXCL_/g' \
        -e 's/%23/_HASH_/g' \
        -e 's/%24/_DOLLAR_/g' \
        -e 's/%26/_AMP_/g' \
        -e 's/%27/_QUOTE_/g' \
        -e 's/%28/_LPAR_/g' \
        -e 's/%29/_RPAR_/g' \
        -e 's/%2C/_COMMA_/g' \
        -e 's/%2F/\//g' \
        -e 's/%3A/:/g' \
        -e 's/%3B/;/g' \
        -e 's/%3D/=/g' \
        -e 's/%3F/?/g' \
        -e 's/%40/@/g' \
        -e 's/%5B/[/g' \
        -e 's/%5C/\\/g' \
        -e 's/%5D/]/g' \
        -e 's/%7E/~/g' \
        -e 's/%60/_BACKQ_/g' \
        -e 's/%22/_DQUOT_/g' \
        -e 's/%3C/</g' \
        -e 's/%3E/>/g' \
        -e 's/%25/%/g' \
        -e 's/%20/ /g' \
        -e 's/+/ /g' \
        -e 's/_EXCL_/!/g' \
        -e 's/_HASH_/#/g' \
        -e 's/_DOLLAR_/$/g' \
        -e 's/_AMP_/\&/g' \
        -e "s/_QUOTE_/'/g" \
        -e 's/_LPAR_/(/g' \
        -e 's/_RPAR_/)/g' \
        -e 's/_COMMA_/,/g' \
        -e 's/_BACKQ_/`/g' \
        -e 's/_DQUOT_/"/g'
}

# --- Санитайз ---
sanitize_alnum() {
    str="$1"
    clean=""
    i=0
    while [ $i -lt ${#str} ]; do
        char="${str:$i:1}"
        case "$char" in
            [a-zA-Z0-9._-]) clean="${clean}${char}" ;;
        esac
        i=$((i+1))
    done
    echo "$clean"
}

# --- Извлечение GET-параметра ---
get_param() {
    key="$1"
    default="$2"
    value=$(echo "$QUERY_STRING" | sed -n "s/.*${key}=\([^&]*\).*/\1/p")
    if [ -z "$value" ]; then
        echo "$default"
    else
        url_decode "$value"
    fi
}

# --- Чтение POST-данных и извлечение параметра ---
post_param() {
    key="$1"
    default="$2"
    _local_data=""
    if [ -z "$_POST_CACHED" ]; then
        _POST_CACHED=$(cat)
        export _POST_CACHED
    fi
    value=$(echo "$_POST_CACHED" | sed -n "s/.*${key}=\([^&]*\).*/\1/p" | tr -d '\r')
    if [ -z "$value" ]; then
        echo "$default"
    else
        url_decode "$value"
    fi
}

# --- Вывод JSON-ответа ---
json_out() {
    echo "Content-type: application/json; charset=utf-8"
    echo ""
    echo "$1"
    exit 0
}

# --- Вывод HTML-заголовков ---
html_header() {
    echo "Content-type: text/html; charset=utf-8"
    echo ""
}

# --- Проверка PID (жив и не зомби) ---
pid_is_alive() {
    [ -z "$1" ] && return 1
    [ ! -d "/proc/$1" ] && return 1
    local s
    s=$(grep "State:" "/proc/$1/status" 2>/dev/null | awk '{print $2}')
    [ "$s" = "Z" ] && return 1
    return 0
}

# --- Поиск PID по паттерну cmdline (pgrep или fallback на ps) ---
find_pids() {
    local pattern="$1"
    if command -v pgrep >/dev/null 2>&1; then
        pgrep -f "$pattern" 2>/dev/null
    else
        ps w 2>/dev/null | grep -v grep | grep -E "$pattern" | awk '{print $1}'
    fi
}

# --- Логирование (с PID) ---
log_action() {
    level="$1"
    message="$2"
    LOGGING_SH="/opt/web_entware/logger/lib/logging.sh"
    
    if [ -f "$LOGGING_SH" ]; then
        . "$LOGGING_SH" 2>/dev/null
        if [ "$LOG_ENABLED" = "true" ]; then
            log_action_original "$level" "$message" 2>/dev/null
        fi
        return 0
    fi
    # Fallback - если logging.sh не найден (никогда не должен выполняться)
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    ip="${REMOTE_ADDR:-localhost}"
    pid=$$
    script_base=$(basename "$SCRIPT_NAME" .cgi)
    LOG_DIR="/tmp/entware/logs"
    mkdir -p "$LOG_DIR" 2>/dev/null
    echo "[$timestamp] [$level] [$ip] [$pid] [$script_base] $message" >> "$LOG_DIR/$(date +%Y-%m-%d).log"
}

get_version() {
    version_file="/opt/web_entware/version.json"
    if [ -f "$version_file" ] && /opt/bin/jq --version >/dev/null 2>&1; then
        /opt/bin/jq -r '.version' "$version_file" 2>/dev/null
    else
        echo "unknown"
    fi
}

# --- Проверка системных зависимостей ---
check_deps_logic() {
    # Базовые утилиты BusyBox
    sed_ok="false"; command -v sed >/dev/null 2>&1 && sed_ok="true"
    awk_ok="false"; command -v awk >/dev/null 2>&1 && awk_ok="true"
    grep_ok="false"; command -v grep >/dev/null 2>&1 && grep_ok="true"
    ps_ok="false"; command -v ps >/dev/null 2>&1 && ps_ok="true"

    # Opkg
    opkg_ok="false"
    if command -v /opt/bin/opkg >/dev/null 2>&1 && /opt/bin/opkg --version >/dev/null 2>&1; then
        opkg_ok="true"
    fi

    # Lighttpd
    lighttpd_installed="false"; /opt/bin/opkg list-installed 2>/dev/null | grep -q "^lighttpd " && lighttpd_installed="true"
    lighttpd_running="false"
    if [ -f /opt/var/run/lighttpd.pid ]; then
        pid=$(cat /opt/var/run/lighttpd.pid 2>/dev/null)
        if [ -n "$pid" ] && pid_is_alive "$pid"; then
            lighttpd_running="true"
        fi
    fi

    # Cron
    cron_installed="false"; /opt/bin/opkg list-installed 2>/dev/null | grep -q "^cron " && cron_installed="true"
    cron_running="false"
    if [ -f /opt/var/run/cron.pid ]; then
        pid=$(cat /opt/var/run/cron.pid 2>/dev/null)
        if [ -n "$pid" ] && pid_is_alive "$pid"; then
            cron_running="true"
        fi
    fi

    # JQ
    jq_ok="false"; command -v /opt/bin/jq >/dev/null 2>&1 && jq_ok="true"

    # IP (ip-full в Entware, может быть встроен в прошивку)
    ip_ok="false"
    ip_path=""
    if command -v ip >/dev/null 2>&1; then
        ip_ok="true"
        ip_path=$(command -v ip)
    fi

    # Пакет ip-full (для рекомендаций)
    ip_pkg_installed="false"
    /opt/bin/opkg list-installed 2>/dev/null | grep -q "^ip-full " && ip_pkg_installed="true"

    # Статус разделов
    # Packages: нужен только opkg
    pkg_status="ok"; [ "$opkg_ok" = "false" ] && pkg_status="missing"

    # Services: нужны cron и jq
    srv_status="ok"
    if [ "$cron_installed" = "false" ] || [ "$jq_ok" = "false" ]; then
        srv_status="missing"
    fi

    # Monitoring: нужны cron (для сбора данных) и jq
    mon_status="ok"
    if [ "$cron_installed" = "false" ] || [ "$jq_ok" = "false" ]; then
        mon_status="partial"
    fi

    # Network: нужен ip (утилита)
    net_status="ok"; [ "$ip_ok" = "false" ] && net_status="missing"

    # Logger: нужен jq
    log_status="ok"; [ "$jq_ok" = "false" ] && log_status="missing"

    # Итоговый статус
    overall="ok"
    if [ "$srv_status" = "missing" ] || [ "$net_status" = "missing" ] || [ "$log_status" = "missing" ]; then
        overall="partial"
    fi
    if [ "$opkg_ok" = "false" ] || [ "$lighttpd_running" = "false" ]; then
        overall="critical"
    fi

    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date '+%Y-%m-%d %H:%M:%S')

    # Вывод JSON (ip - утилита, ip_pkg - пакет Entware)
    printf '{"base":{"opkg":%s,"lighttpd_running":%s,"sed":%s,"awk":%s,"grep":%s,"ps":%s},"deps":{"cron_installed":%s,"cron_running":%s,"jq":%s,"ip":%s,"ip_path":"%s","ip_pkg_installed":%s},"sections":{"packages":"%s","services":"%s","monitoring":"%s","network":"%s","logger":"%s"},"overall_status":"%s","timestamp":"%s"}' \
        "$opkg_ok" "$lighttpd_running" "$sed_ok" "$awk_ok" "$grep_ok" "$ps_ok" \
        "$cron_installed" "$cron_running" "$jq_ok" "$ip_ok" "$ip_path" "$ip_pkg_installed" \
        "$pkg_status" "$srv_status" "$mon_status" "$net_status" "$log_status" \
        "$overall" "$timestamp"
}
